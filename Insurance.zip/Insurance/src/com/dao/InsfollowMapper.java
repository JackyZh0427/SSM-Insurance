package com.dao;



import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.entity.Insfollow;


public interface InsfollowMapper {
	
	
	public List<Insfollow> findInsfollow(int id);
	
	public int addfollow(@Param("f") Insfollow insfollow,@Param("id") int id);
	
	
}
