package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.entity.MenuUtil;
import com.entity.PageMenu;
import com.entity.Permmenu;
import com.entity.Sysuser;
import com.service.MenuUtilService;
import com.service.RolesService;

@Controller
public class TreeMenuController {

	@Resource
	private MenuUtilService ms;
	@Resource
	private RolesService rs;

	@ResponseBody
	@RequestMapping("/treeMenu.do")
	public void treeMenu(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		Sysuser sysuser = (Sysuser) session.getAttribute("sysuser");
		// 查询所有的菜单树状结构
		List<MenuUtil> msList = ms.findAll();
		// 前台展示树状结构所需要的属性集合
		List<PageMenu> list = new ArrayList<PageMenu>();
		// 获取用户对应的角色rid
		int rid = sysuser.getRid();
		// 通过角色的rid查询角色对应的权限菜单(从中间表查询)
		List<Permmenu> list2 = rs.findByRid(rid);
		for (MenuUtil menuUtil : msList) {
			String text = menuUtil.getText();
			boolean flag = false;
			for (Permmenu permmenu : list2) {
				String menuname = permmenu.getMenuname();
				if (menuname.equals(text)) {
					flag = true;
					break;
				}
			}
			if(flag){
				String id = menuUtil.getText();
				String pid = menuUtil.getPtext();
				String text2 = menuUtil.getMenuText();
				String url = menuUtil.getMenuUrl();
				Map<String, String> map = new HashMap<String, String>();
				map.put("url", url);
				PageMenu pageMenu = new PageMenu(id, pid, text2, map);
				list.add(pageMenu);
			}
		}
		String jsonString = JSONObject.toJSONString(list);
		out.println(jsonString);
	}
}
