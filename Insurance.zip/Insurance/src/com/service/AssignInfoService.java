package com.service;

import java.util.List;

import com.entity.Freeinsrecord;

public interface AssignInfoService {
	
	
	public List<Freeinsrecord> findByPage(Integer page,Integer rows);
	
	
	public Long findCount();//免险已经确认的总人数
	
	
	
	public List<Freeinsrecord> findByUserId(int id);
	
	public boolean updFreeIns(int id);
}
