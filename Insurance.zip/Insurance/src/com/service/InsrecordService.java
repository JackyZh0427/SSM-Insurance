package com.service;


import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.entity.Freeinsrecord;
import com.entity.Insfollow;
import com.entity.Insproduct;
import com.entity.Insrecord;

public interface InsrecordService {
	

	public boolean addInsrecord(@Param("f") Freeinsrecord freeinsrecord,@Param("uid") int uid);
	
	
	public List<Insrecord> findByPage(Integer page,Integer rows);
	
	public Long findCount();
	
	public boolean updateIns(Insrecord ins);
	
	public List<Insproduct> findInsProduct();
	
	public List<Insfollow> findInsfollow(int id);
	
	public boolean addfollow(@Param("f") Insfollow insfollow,@Param("id") int id);
	
	public boolean updateIns2(int id);//修改状态
	
	public List<Insrecord> findByInsStatus();


	public boolean updateIns3(int id);
	
	public List<Insrecord> findByInsStatus2();

	boolean addproduct(int pid, int id);
}
