package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.entity.Freeinsrecord;
import com.entity.Pagebean;
import com.entity.ResultMsg;
import com.service.FreeInsService;
import com.util.SysMsgManager;

@Controller
@RequestMapping("/confirmfreeInsrecord")
public class ConfirmfreeInsController {

	@Resource
	private FreeInsService fis;

	@ResponseBody
	@RequestMapping("/confirmfree.do")
	public void freeIns(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=================确认免费险,免险提交人员====================");
		int page = Integer.parseInt(request.getParameter("page"));
		int rows = Integer.parseInt(request.getParameter("rows"));
		List<Freeinsrecord> flist = fis.findByPage2(page, rows);
		Long total = fis.findCount2();// 总数
		System.out.println(total);
		Pagebean pb = new Pagebean();
		pb.setTotal(total);
		pb.setRows(flist);
		out.println(JSONObject.toJSONString(pb));
	}
	
	@ResponseBody
	@RequestMapping("/confirmfreeIns.do")
	public void confirmfreeIns(int id,HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=====================确认免费险=======================");
		boolean flag = fis.updateStatus2(id);
		ResultMsg rm = new ResultMsg();
		if (flag) {
			rm.setFlag(true);
			rm.setMsg(SysMsgManager.confirmfreeSucc);
		} else {
			rm.setFlag(false);
			rm.setMsg(SysMsgManager.confirmfreeError);
		}
		out.println(JSONObject.toJSONString(rm));
		
	}
	

}
