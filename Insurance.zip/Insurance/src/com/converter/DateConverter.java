package com.converter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.springframework.core.convert.converter.Converter;

public class DateConverter implements Converter<String, Date> {

	@Override
	public Date convert(String str) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		if (str != null && !str.equals("")) {
			try {
				date = format.parse(str);
			} catch (ParseException e) {
				System.out.println("转化Date类型失败");
			}
		}
		return date;
	}

}