package com.util;
/**
 * 
 * 系统消息管理
 *
 */
public class SysMsgManager {
	//菜单名字长度
	public final static int  menuNameLength=5;
	//设置初始密码
	public final static String initPwd="123456";
	
	
	//删除免险记录
	public final static String  delFreeInsMsgSucc="删除记录成功!";
	public final static String  delFreeInsMsgError="删除记录失败!";
	
	//提交免险状态
	public final static String  submitFreeInsMsgSucc="提交记录成功!";
	public final static String  submitFreeInsMsgError="提交记录失败!";
	
	//添加免险记录提示
	public final static String  addFreeInsMsgSucc="添加记录成功!";
	public final static String  addFreeInsMsgError="添加记录失败!";
	
	/***********************************************************/
	//添加角色提示
	public final static String  addRolesMsgSucc="添加角色成功!";
	public final static String  addRolesMsgError="添加角色失败!";
	
	//编辑角色提示
	public final static String  updRolesMsgSucc="编辑角色成功!";
	public final static String  updRolesMsgError="编辑角色失败!";
	
	//授权角色提示
	public final static String  grantRolesMsgSucc="授权角色成功!";
	public final static String  grantRolesMsgError="授权角色失败!";
	
	//删除免险记录
	public final static String  delRolesSucc="删除记录成功!";
	public final static String  delRolesError="删除记录失败!";
	
	//指派免险记录
	public final static String  assignRolesSucc="指派角色成功!";
	public final static String  assignRolesError="指派角色失败!";
	
	//重置密码
	public final static String  resetPwdRolesSucc="重置密码成功!";
	public final static String  resetPwdRolesError="重置密码失败!";
	
	//修改
	public final static String  UpdateUserSucc="修改成功!";
	public final static String  UpdateUserError="修改失败!";
	
	//添加角色提示
	public final static String  addUsersSucc="添加角色成功!";
	public final static String  addUsersError="添加角色失败!";
	
	//删除用户记录
	public final static String  delUsersSucc="删除记录成功!";
	public final static String  delUsersError="删除记录失败!";
	
	//登录验证
	public final static String  loginMsgSucc="登录成功!";
	public final static String  loginMsgError="登录失败!";
	//登录验证
	public final static String  updPwdSucc="更改密码成功!";
	public final static String  updPwdError="初始密码有误!";
	
	//确认免费险人员
	public final static String  confirmfreeSucc="确认成功!";
	public final static String  confirmfreeError="确认失败!";
	
	//分配
	public final static String  assignfreeSucc="分配成功!";
	public final static String  assignfreeError="分配失败!";
	
	//修改
	public final static String  UpdateInsrecordSucc="修改成功!";
	public final static String  UpdateInsrecordError="修改失败!";
	
	////添加回访记录提示
	public final static String  addfollowMsgSucc="添加回访记录成功!";
	public final static String  addfollowMsgError="添加回访记录失败!";
	
	//添加回访记录提示
	public final static String  SubmitINsMsgSucc="提交并确认成功!";
	public final static String  SubmitINsMsgError="提交确认失败!";
	
	//添加角色提示
	public final static String  BuyInsMsgSucc="购买成功!";
	public final static String  BuyInsMsgError="购买失败!";

}
