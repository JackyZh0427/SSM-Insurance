package com.entity;

import java.io.Serializable;
import java.util.Map;

public class PageMenu implements Serializable{
	private String id;
	private String pid;
	private String text;
	private boolean checked=false;
	private Map<String,String> attributes;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public boolean isChecked() {
		return checked;
	}
	public void setChecked(boolean checked) {
		this.checked = checked;
	}
	public Map<String, String> getAttributes() {
		return attributes;
	}
	public void setAttributes(Map<String, String> attributes) {
		this.attributes = attributes;
	}
	public PageMenu(String id, String pid, String text, boolean checked,
			Map<String, String> attributes) {
		super();
		this.id = id;
		this.pid = pid;
		this.text = text;
		this.checked = checked;
		this.attributes = attributes;
	}
	public PageMenu() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PageMenu(String id, String pid, String text,
			Map<String, String> attributes) {
		super();
		this.id = id;
		this.pid = pid;
		this.text = text;
		this.attributes = attributes;
	}
	
}
