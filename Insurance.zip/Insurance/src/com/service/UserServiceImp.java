package com.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dao.UserMapper;
import com.entity.Sysuser;

@Service
public class UserServiceImp implements UserService {
	@Resource
	private UserMapper um;

	@Override
	public List<Sysuser> findAll() {
		List<Sysuser> userList = um.findAll();
		if (userList == null) {
			userList = new ArrayList<Sysuser>();
		}
		return userList;
	}

	@Override
	public boolean addUserAssignRoles(int id, int rid) {
		System.out.println("进入addUserAssignRoles方法了...");
		int i = um.addUserAssignRoles(id, rid);
		if (i > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean resetUserPwd(int id, String usePwd) {
		int flag = um.resetUserPwd(id, usePwd);
		if (flag > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean updUsers(Sysuser user) {
		int i = um.updUsers(user);
		if (i > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean addUsers(Sysuser user) {
		int i = um.addUsers(user);
		if (i > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean delUsers(int id) {
		int i = um.delUsers(id);
		if (i > 0) {
			return true;
		}
		return false;
	}
	//登录验证
	@Override
	public Sysuser Logincheck(Sysuser user) {
		Sysuser users = null;
		users = um.Logincheck(user);
		return users;
		
	}

	@Override
	public boolean addNewPwd(Sysuser user) {
		int i = um.addNewPwd(user);
		if (i > 0) {
			return true;
		}
		return false;
	}

	@Override
	public List<Sysuser> findbyRid() {
		List<Sysuser> list = um.findbyRid();
		if (list == null) {
			list = new ArrayList<Sysuser>();
		}
		return list;
	}
	
}
