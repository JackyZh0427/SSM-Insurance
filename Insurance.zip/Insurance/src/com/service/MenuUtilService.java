package com.service;

import java.util.List;

import com.entity.MenuUtil;

public interface MenuUtilService {
	
	public List<MenuUtil> findAll();
}
