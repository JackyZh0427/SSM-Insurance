package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.entity.Sysuser;

public interface UserMapper {
	
	public List<Sysuser> findAll();
	
	public List<Sysuser> findbyRid();
	//给用户指派角色
	public int addUserAssignRoles(@Param("id") int id,@Param("rid") int rid);
	//重置密码
	public int resetUserPwd(@Param("id") int id,@Param("usePwd") String usePwd);
	//修改
	public int updUsers(Sysuser user);
	//添加
	public int addUsers(Sysuser user);
	//删除
	public int delUsers(int id);
	//登录验证
	public Sysuser Logincheck(Sysuser user);
	//设置新密码
	public int addNewPwd(Sysuser user);
	
}
