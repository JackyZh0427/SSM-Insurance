package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jasper.tagplugins.jstl.core.ForEach;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.entity.MenuUtil;
import com.entity.PageMenu;
import com.entity.Pagebean;
import com.entity.Permmenu;
import com.entity.ResultMsg;
import com.entity.Roles;
import com.service.MenuUtilService;
import com.service.RolesService;
import com.util.SysMsgManager;

@Controller
@RequestMapping("/RolesControl")
public class RolesController {

	@Resource
	private RolesService rs;
	@Resource
	private MenuUtilService mus;

	@ResponseBody
	@RequestMapping("/rolesControl.do")
	public void freeIns(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=================分页====================");
		int page = Integer.parseInt(request.getParameter("page"));
		int rows = Integer.parseInt(request.getParameter("rows"));
		List<Roles> flist = rs.findByPage(page, rows);
		Long total = rs.findCount();// 总数
		System.out.println(total);
		Pagebean pb = new Pagebean();
		pb.setTotal(total);
		pb.setRows(flist);
		out.println(JSONObject.toJSONString(pb));
	
	}
	@ResponseBody
	@RequestMapping("/addRoles.do")
	public void addRoles(Roles roles,HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("==================添加===================");
		boolean addRolesflag = rs.addRoles(roles);
		out.println(JSONObject.toJSONString(addRolesflag));
	}
	@ResponseBody
	@RequestMapping("/updRoles.do")
	public void updRoles(Roles roles,HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("==================修改===================");
		System.out.println(roles.toString());
		boolean updroles = rs.updRoles(roles);
		out.println(JSONObject.toJSONString(updroles));
	}
	//角色授权菜单
	@ResponseBody
	@RequestMapping("/grantTreeRoles.do")
	public void grantRoles(int rid,HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("==================授权===================");
		//PageMenu集合
		List<PageMenu> list=new ArrayList<PageMenu>();
		//查询角色对应的菜单
		List<Permmenu> list2 = rs.findByRid(rid);
		//查询所有的菜单
		List<MenuUtil> findlist = mus.findAll();
		for (MenuUtil menuUtil : findlist) {
			//定义一个变量
			boolean checked=false;
			//所有菜单和角色对应的菜单进行比较，如果一样,则设置checked为true
			for (Permmenu permmenu : list2) {
				if(permmenu.getMenuname().equals(menuUtil.getText()) && permmenu.getMenuname().length()==5){
					checked=true;
					break;
				}
			}
			String id=menuUtil.getText();
			String pid=menuUtil.getPtext();
			String text=menuUtil.getMenuText();
			String url=menuUtil.getMenuUrl();
			Map<String,String> map=new HashMap<String,String>();
			map.put("url",url);
			//将遍历的每一个菜单放入到PageMenu对象中
			PageMenu pm=new PageMenu(id, pid, text,checked,map);
			//将PageMenu对象放入集合中
			list.add(pm);
			
		}
		out.println(JSONObject.toJSONString(list));
	}
	//角色授权
		@ResponseBody
		@RequestMapping("/GrantRoles.do")
		public void GrantRoles(Permmenu permmenu,HttpServletRequest request,HttpServletResponse response) throws IOException{
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out=response.getWriter();
			boolean flag = rs.grantRoles(permmenu);
			ResultMsg rm=new ResultMsg();
			if(flag){
				rm.setFlag(true);
				rm.setMsg(SysMsgManager.grantRolesMsgSucc);
			}else{
				rm.setFlag(false);
				rm.setMsg(SysMsgManager.grantRolesMsgError);
			}
			String strRm=JSONObject.toJSONString(rm);
			out.print(strRm);
		}
		
		//删除角色
		@ResponseBody
		@RequestMapping("/DelRoles.do")
		public void delRoles(int id,HttpServletRequest request, HttpServletResponse response) throws IOException {
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			System.out.println("==================添加===================");
			boolean flag = rs.delRoles(id);
			ResultMsg rm=new ResultMsg();
			if(flag){
				rm.setFlag(true);
				rm.setMsg(SysMsgManager.delRolesSucc);
			}else{
				rm.setFlag(false);
				rm.setMsg(SysMsgManager.delRolesError);
			out.println(JSONObject.toJSONString(rm));
			}
		}



}
