package com.dao;

import java.util.List;

import com.entity.MenuUtil;

public interface MenuUtilMapper {
	
	public List<MenuUtil> findAll();
}
