package com.service;

import java.util.List;


import com.entity.Sysuser;

public interface UserService {

	public List<Sysuser> findAll();
	
	public boolean addUserAssignRoles(int id, int rid);
	
	public boolean resetUserPwd(int id,String usePwd);

	public boolean updUsers(Sysuser user);

	public boolean addUsers(Sysuser user);

	public boolean delUsers(int id);
	//登录验证
	public Sysuser Logincheck(Sysuser user);
	//设置新密码
	public boolean addNewPwd(Sysuser user);

	public List<Sysuser> findbyRid();
	

}
