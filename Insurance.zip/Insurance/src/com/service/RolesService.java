package com.service;

import java.util.List;

import com.entity.Permmenu;
import com.entity.Roles;

public interface RolesService {
	
	public List<Roles> findAll();
	
	public boolean addRoles(Roles roles);

	public List<Roles> findByPage(int page, int rows);

	public Long findCount();
	
	public boolean updRoles(Roles roles);
	
	//角色授权
	public boolean grantRoles(Permmenu pm);
	//查询角色对应的菜单
	public List<Permmenu> findByRid(int rid);
	//删除角色
	public boolean delRoles(int id);

}
