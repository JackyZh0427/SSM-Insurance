package com.entity;

import java.io.Serializable;
import java.sql.Date;

public class Insrecord implements Serializable {
	private Integer id;
	private String cstmName;
	private Integer cstmAge;
	private Integer cstmSex;
	private String cstmPhone;
	private Date beginTime;
	private String addr;
	private Integer isMarry;
	private Integer nation;
	private Integer intention;
	private String idcard;
	private String bankCard;
	private String wechat;
	private String beneficiary;
	private Integer userId;
	private Integer productId;
	private String remark;
	private Integer status;
	private Integer cycle;
	private Integer price;

	public Integer getCycle() {
		return cycle;
	}

	public void setCycle(Integer cycle) {
		this.cycle = cycle;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCstmName() {
		return cstmName;
	}

	public void setCstmName(String cstmName) {
		this.cstmName = cstmName;
	}

	public Integer getCstmAge() {
		return cstmAge;
	}

	public void setCstmAge(Integer cstmAge) {
		this.cstmAge = cstmAge;
	}

	public Integer getCstmSex() {
		return cstmSex;
	}

	public void setCstmSex(Integer cstmSex) {
		this.cstmSex = cstmSex;
	}

	public String getCstmPhone() {
		return cstmPhone;
	}

	public void setCstmPhone(String cstmPhone) {
		this.cstmPhone = cstmPhone;
	}

	public Date getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public Integer getIsMarry() {
		return isMarry;
	}

	public void setIsMarry(Integer isMarry) {
		this.isMarry = isMarry;
	}

	public Integer getNation() {
		return nation;
	}

	public void setNation(Integer nation) {
		this.nation = nation;
	}

	public String getIdcard() {
		return idcard;
	}

	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}

	public String getBankCard() {
		return bankCard;
	}

	public Integer getIntention() {
		return intention;
	}

	public void setIntention(Integer intention) {
		this.intention = intention;
	}

	public void setBankCard(String bankCard) {
		this.bankCard = bankCard;
	}

	public String getWechat() {
		return wechat;
	}

	public void setWechat(String wechat) {
		this.wechat = wechat;
	}

	public String getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(String benficiary) {
		this.beneficiary = benficiary;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Insrecord() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Insrecord(Integer id, String cstmName, Integer cstmAge, Integer cstmSex, String cstmPhone, Date beginTime,
			String addr, Integer isMarry, Integer nation, Integer intention, String idcard, String bankCard,
			String wechat, String beneficiary, Integer userId, Integer productId, String remark, Integer status) {
		super();
		this.id = id;
		this.cstmName = cstmName;
		this.cstmAge = cstmAge;
		this.cstmSex = cstmSex;
		this.cstmPhone = cstmPhone;
		this.beginTime = beginTime;
		this.addr = addr;
		this.isMarry = isMarry;
		this.nation = nation;
		this.intention = intention;
		this.idcard = idcard;
		this.bankCard = bankCard;
		this.wechat = wechat;
		this.beneficiary = beneficiary;
		this.userId = userId;
		this.productId = productId;
		this.remark = remark;
		this.status = status;
	}

}
