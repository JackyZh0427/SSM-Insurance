package com.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dao.PermMapper;
import com.dao.RolesMapper;
import com.entity.Permmenu;
import com.entity.Roles;

@Service
public class RolesServiceImp implements RolesService {
	@Resource
	private RolesMapper rm;
	@Resource
	private PermMapper pm;

	@Override
	public List<Roles> findAll() {
		List<Roles> RoleList = rm.findAll();
		if (RoleList == null) {
			RoleList = new ArrayList<Roles>();
		}
		return RoleList;
	}

	@Override
	public boolean addRoles(Roles roles) {
		int i = rm.addRoles(roles);
		if (i > 0) {
			return true;
		}
		return false;
	}

	@Override
	public List<Roles> findByPage(int page, int rows) {
		Integer start = (page - 1) * rows;
		List<Roles> rlist = rm.findByPage(start, rows);
		if (rlist == null) {
			rlist = new ArrayList<Roles>();
		}
		return rlist;
	}

	@Override
	public Long findCount() {
		Long count = 0L;
		count = rm.findCount();
		System.out.println(count);
		if (count == null) {
			count = 0L;
		}
		return count;
	}

	@Override
	public boolean updRoles(Roles roles) {
		int i = rm.updRoles(roles);
		if (i > 0) {
			return true;
		}
		return false;
	}

	// 角色授权
	@Override
	public boolean grantRoles(Permmenu permmenu) {
		Integer rid = permmenu.getRid();
		int delbyRid = rm.delByRid(rid);// 先将原来角色对相应权限菜单先删除掉
		String menunames = permmenu.getMenuname();
		int count = 0;
		String[] splitmenuname = menunames.split(",");
		for (int i = 0; i < splitmenuname.length; i++) {
			String menuname = splitmenuname[i];
			System.out.println(menuname);
			Permmenu permmenu2 = new Permmenu(rid, menuname, null);
			count += rm.grantRoles(permmenu2);
		}
		if (count < splitmenuname.length) {
			return false;
		}
		return true;
	}

	// 通过角色rid查询对应权限菜单
	@Override
	public List<Permmenu> findByRid(int rid) {
		List<Permmenu> plist = pm.findByRid(rid);
		if (plist == null) {
			plist = new ArrayList<Permmenu>();
		}
		return plist;

	}

	@Override
	public boolean delRoles(int id) {
		int roles = rm.delRoles(id);
		if (roles > 0) {
			return true;
		}
		return false;
	}

}
