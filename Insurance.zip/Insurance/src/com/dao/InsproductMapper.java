package com.dao;



import java.util.List;


import com.entity.Insproduct;


public interface InsproductMapper {
	
	
	public List<Insproduct> findInsProduct();

}
