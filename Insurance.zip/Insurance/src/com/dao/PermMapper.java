package com.dao;

import java.util.List;

import com.entity.Permmenu;

public interface PermMapper {
	
	//通过rid查询角色对应的权限菜单
	public List<Permmenu> findByRid(int rid);
}
