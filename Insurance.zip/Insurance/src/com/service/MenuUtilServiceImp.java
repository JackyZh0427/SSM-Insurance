package com.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dao.MenuUtilMapper;
import com.entity.MenuUtil;
@Service
public class MenuUtilServiceImp implements MenuUtilService{
	
	@Resource
	private MenuUtilMapper mapper;//ע��dao��ӿ�
	@Override
	public List<MenuUtil> findAll() {
		List<MenuUtil> mlist = mapper.findAll();
		if(mlist==null){
			mlist = new ArrayList<MenuUtil>();
		}
		return mlist;
	}
	
}
