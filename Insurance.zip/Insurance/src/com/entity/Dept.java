package com.entity;

import java.io.Serializable;

public class Dept implements Serializable{
	private Integer id;
	private String dname;
	private String remark;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Dept(Integer id, String dname, String remark) {
		super();
		this.id = id;
		this.dname = dname;
		this.remark = remark;
	}
	public Dept() {
		super();
		// TODO Auto-generated constructor stub
	}
}
