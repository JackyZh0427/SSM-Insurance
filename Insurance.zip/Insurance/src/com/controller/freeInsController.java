package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.entity.Freeinsrecord;
import com.entity.Pagebean;
import com.entity.Sysuser;
import com.service.FreeInsService;

@Controller
@RequestMapping("/freeInsrecord")
public class freeInsController {

	@Resource
	private FreeInsService fis;

	@ResponseBody
	@RequestMapping("/freeIns.do")
	public void freeIns(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=================分页====================");
		int page = Integer.parseInt(request.getParameter("page"));
		int rows = Integer.parseInt(request.getParameter("rows"));
		HttpSession session = request.getSession();
		Sysuser user =(Sysuser) session.getAttribute("sysuser");
		int uid = user.getId();
		List<Freeinsrecord> flist = fis.findByPage(uid,page, rows);
		Long total = fis.findCount();//总数
		System.out.println(total);
		Pagebean pb = new Pagebean();
		pb.setTotal(total);
		pb.setRows(flist);
		out.println(JSONObject.toJSONString(pb));
	}

	@ResponseBody
	@RequestMapping("/updfreeIns.do")
	// 修改免险
	public void updFreeIns(Freeinsrecord freeinsrecord, HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=====================更新=======================");
		boolean updateFreeIns = fis.updateFreeIns(freeinsrecord);
		out.println(JSONObject.toJSONString(updateFreeIns));
		if (updateFreeIns) {
			try {
				request.getRequestDispatcher("/freeIns/freeInsDwork.jsp").forward(request, response);
			} catch (ServletException e) {
				System.out.println("跳转失败");
			}
		}
	}

	@ResponseBody
	@RequestMapping("/deletefreeIns.do")
	public void deleteIns(int id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=====================删除=======================");
		System.out.println(id);
		boolean deleteflag = fis.deletefreeIns(id);
		out.println(JSONObject.toJSONString(deleteflag));

	}

	@ResponseBody
	@RequestMapping("/updStatusfreeIns.do")
	public void updStatus(int id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=====================修改状态=======================");
		System.out.println(id);
		boolean updateStatus = fis.updateStatus(id);
		out.println(JSONObject.toJSONString(updateStatus));
	}

	@ResponseBody
	@RequestMapping("/insertfreeIns.do")
	public void AddfreeIns(Freeinsrecord freeinsrecord, HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=====================添加=======================");
		boolean insertfreeIns = fis.insertfreeIns(freeinsrecord);
		out.println(JSONObject.toJSONString(insertfreeIns));
	}
	
}
