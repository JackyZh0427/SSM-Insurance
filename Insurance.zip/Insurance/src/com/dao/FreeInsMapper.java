package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.entity.Freeinsrecord;

public interface FreeInsMapper {
	
	public List<Freeinsrecord> findAll();
	
	public List<Freeinsrecord> findByPage(@Param("uid") int uid,@Param("start") Integer start,@Param("rows") Integer rows);
	
	public List<Freeinsrecord> findByPage2(@Param("start") Integer start,@Param("rows") Integer rows);
	
	public Long findCount();
	
	public Long findCount2();
	
	public int updateFreeIns(Freeinsrecord fir);//更新
	
	public Freeinsrecord findById(int id);//通过id查询
	
	public int deletefreeIns(int id);
	
	public int updateStatus(int id);  //通过id修改状态
	
	public int updateStatus2(int id);  //通过id修改状态
	
	public int insertfreeIns(Freeinsrecord fir); //添加
	
	public int updateUserID(@Param("id") Integer id,@Param("uid") Integer uid);  //通过id修改UserId
	
	public List<Freeinsrecord> findByUserId(int id);
}
