package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.entity.Freeinsrecord;
import com.entity.Permmenu;
import com.entity.Roles;

public interface RolesMapper {
	
	public List<Roles> findAll();
	
	public int addRoles(Roles roles);
	
	public List<Roles> findByPage(@Param("start")Integer start,@Param("rows")Integer rows);
	
	public Long findCount();
	
	public int updRoles(Roles roles);
	//角色授权
	public int grantRoles(Permmenu pm);
	//通过rid删除角色对应的权限
	public int delByRid(Integer rid);
	//删除角色
	public int delRoles(int id);
	
}
