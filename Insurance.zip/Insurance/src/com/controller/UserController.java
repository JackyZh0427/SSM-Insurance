package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.entity.ResultMsg;
import com.entity.Roles;
import com.entity.Sysuser;
import com.service.RolesService;
import com.service.UserService;
import com.util.SysMsgManager;

@Controller
@RequestMapping("/UserControl")
public class UserController {

	@Resource
	private UserService us;
	@Resource
	private RolesService rs;

	@ResponseBody
	@RequestMapping("/usersControl.do")
	public void funUsers(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("==============展示================");
		List<Sysuser> sysList = us.findAll();
		out.println(JSONObject.toJSONString(sysList));

	}
	@ResponseBody
	@RequestMapping("/assignInfo.do")
	public void findByRid(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("==============展示================");
		List<Sysuser> list = us.findbyRid();
		out.println(JSONObject.toJSONString(list));

	}

	// 查看所有角色
	@ResponseBody
	@RequestMapping("/findAllroles.do")
	public void findAllroles(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("==============查询role表================");
		List<Roles> roleList = rs.findAll();
		for (Roles roles2 : roleList) {
			System.out.println(roles2);
		}

		out.println(JSONObject.toJSONString(roleList));

	}

	// 指派角色
	@ResponseBody
	@RequestMapping("/assignRoles.do")
	public void assignUsersRoles(int id, int rid, HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("==============指派角色================");
		boolean flag = us.addUserAssignRoles(id, rid);
		ResultMsg rm = new ResultMsg();
		if (flag) {
			rm.setFlag(true);
			rm.setMsg(SysMsgManager.assignRolesSucc);
		} else {
			rm.setFlag(false);
			rm.setMsg(SysMsgManager.assignRolesError);
		}
		out.println(JSONObject.toJSONString(rm));

	}

	// 重置密码
	@ResponseBody
	@RequestMapping("/resetUserPwd.do")
	public void resetUserPwd(int id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("==============重置密码================");
		boolean flag = us.resetUserPwd(id, SysMsgManager.initPwd);
		ResultMsg rm = new ResultMsg();
		if (flag) {
			rm.setFlag(true);
			rm.setMsg(SysMsgManager.resetPwdRolesSucc);
		} else {
			rm.setFlag(false);
			rm.setMsg(SysMsgManager.resetPwdRolesError);
		}
		out.println(JSONObject.toJSONString(rm));

	}
	// 修改
	@ResponseBody
	@RequestMapping("/updUsers.do")
	public void updUsers(Sysuser user, HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("==============修改================");
		boolean flag = us.updUsers(user);
		ResultMsg rm = new ResultMsg();
		if (flag) {
			rm.setFlag(true);
			rm.setMsg(SysMsgManager.UpdateUserSucc);
		} else {
			rm.setFlag(false);
			rm.setMsg(SysMsgManager.UpdateUserError);
		}
		out.println(JSONObject.toJSONString(rm));

	}
	// 修改
	@ResponseBody
	@RequestMapping("/addUsers.do")
	public void addUsers(Sysuser user, HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("==============修改================");
		boolean flag = us.addUsers(user);
		ResultMsg rm = new ResultMsg();
		if (flag) {
			rm.setFlag(true);
			rm.setMsg(SysMsgManager.addUsersSucc);
		} else {
			rm.setFlag(false);
			rm.setMsg(SysMsgManager.addUsersError);
		}
		out.println(JSONObject.toJSONString(rm));

	}
	//删除
	@ResponseBody
	@RequestMapping("/delUsers.do")
	public void delUsers(int id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("==============删除================");
		boolean flag = us.delUsers(id);
		ResultMsg rm = new ResultMsg();
		if (flag) {
			rm.setFlag(true);
			rm.setMsg(SysMsgManager.delUsersSucc);
		} else {
			rm.setFlag(false);
			rm.setMsg(SysMsgManager.delUsersError);
		}
		out.println(JSONObject.toJSONString(rm));

	}
	//登录验证
	@ResponseBody
	@RequestMapping("/checkLogin.do")
	public void assignUsersRoles(Sysuser user,HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("==============登录验证================");
		HttpSession session = request.getSession();
		System.out.println(user.getName()+user.getPwd());
		Sysuser sysuser = us.Logincheck(user);
		ResultMsg rm=new ResultMsg();
		if(sysuser!=null){
			//设置登录成功
			rm.setFlag(true);
			//将用户放入到session中
			session.setAttribute("sysuser", sysuser);
		}else{
			//设置登录失败
			rm.setFlag(false);
			rm.setMsg(SysMsgManager.loginMsgError);
		}
		out.println(JSONObject.toJSONString(rm));
	}
	//更改密码
	@ResponseBody
	@RequestMapping("/updPwd.do")
	public void updPwd(String pwd,String newpwd,HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("==============修改密码================");
		HttpSession session = request.getSession();
		Sysuser user = (Sysuser) session.getAttribute("sysuser");
		//查到该用户对应的密码
		String upwd = user.getPwd();
		System.out.println(upwd);
		ResultMsg rm=new ResultMsg();
		if(pwd.equals(upwd)){
			//设置新密码
			user.setPwd(newpwd);
			boolean flag = us.addNewPwd(user);
			System.out.println(flag);
			if(flag){
				rm.setFlag(true);
				rm.setMsg(SysMsgManager.updPwdSucc);
			}
		}else{
			rm.setFlag(false);
			rm.setMsg(SysMsgManager.updPwdError);
		}
		out.println(JSONObject.toJSONString(rm));
		
	}

}
