package com.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dao.FreeInsMapper;
import com.entity.Freeinsrecord;
import com.entity.Insrecord;

@Service
public class FreeInsServiceImp implements FreeInsService {

	@Resource
	private FreeInsMapper fim;

	@Override
	public List<Freeinsrecord> findAll() {
		List<Freeinsrecord> flist = fim.findAll();
		if (flist == null) {
			flist = new ArrayList<Freeinsrecord>();
		}
		return flist;
	}

	@Override
	public List<Freeinsrecord> findByPage(int uid,Integer page, Integer rows) {
		Integer start = (page - 1) * rows;
		List<Freeinsrecord> flist = fim.findByPage(uid,start, rows);
		if (flist == null) {
			flist = new ArrayList<Freeinsrecord>();
		}
		return flist;
	}
	@Override
	public List<Freeinsrecord> findByPage2(Integer page, Integer rows) {
		Integer start = (page - 1) * rows;
		List<Freeinsrecord> flist = fim.findByPage2(start, rows);
		if (flist == null) {
			flist = new ArrayList<Freeinsrecord>();
		}
		return flist;
	}

	@Override
	public Long findCount() {
		Long count = 0L;
		count = fim.findCount();
		System.out.println(count);
		if (count == null) {
			count = 0L;
		}
		return count;
	}

	@Override
	public boolean updateFreeIns(Freeinsrecord fir) {
		int ins = fim.updateFreeIns(fir);
		System.out.println("已修改影响行数:"+ins);
		if (ins == 0) {
			return false;
		}
		return true;

	}

	@Override
	public boolean deletefreeIns(int id) {
		int i = 0;
		i = fim.deletefreeIns(id);
		System.out.println("delete=" + i);
		if (i == 0) {
			return false;
		}
		return true;
	}

	@Override
	public boolean updateStatus(int id) {
		int flag = 0;
		flag = fim.updateStatus(id);
		if (flag > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean insertfreeIns(Freeinsrecord fir) {
		int flag = 0;
		flag = fim.insertfreeIns(fir);
		if (flag > 0) {
			return true;
		}
		return false;
	}

	//查询免险提交人员的总数
	@Override
	public Long findCount2() {
		Long count = 0L;
		count = fim.findCount2();
		System.out.println(count);
		if (count == null) {
			count = 0L;
		}
		return count;
	}

	@Override
	public boolean updateStatus2(int id) {
		int flag = 0;
		flag = fim.updateStatus2(id);
		if (flag > 0) {
			return true;
		}
		return false;
	}

}
