package com.entity;

import java.io.Serializable;

public class MenuUtil implements Serializable{
	private Integer id;
	private String menuText;
	private String menuUrl;
	private Integer level;
	private String remark;
	private String ptext;
	private String text;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getMenuText() {
		return menuText;
	}
	public void setMenuText(String menuText) {
		this.menuText = menuText;
	}
	public String getMenuUrl() {
		return menuUrl;
	}
	public void setMenuUrl(String menuUrl) {
		this.menuUrl = menuUrl;
	}
	public Integer getLevel() {
		return level;
	}
	public void setLevel(Integer level) {
		this.level = level;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getPtext() {
		return ptext;
	}
	public void setPtext(String ptext) {
		this.ptext = ptext;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public MenuUtil() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MenuUtil(Integer id, String menuText, String menuUrl, Integer level,
			String remark, String ptext, String text) {
		super();
		this.id = id;
		this.menuText = menuText;
		this.menuUrl = menuUrl;
		this.level = level;
		this.remark = remark;
		this.ptext = ptext;
		this.text = text;
	}
	
}
