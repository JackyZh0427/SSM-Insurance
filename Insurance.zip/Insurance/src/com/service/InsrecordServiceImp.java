package com.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dao.InsfollowMapper;
import com.dao.InsproductMapper;
import com.dao.InsrecordMapper;
import com.entity.Freeinsrecord;
import com.entity.Insfollow;
import com.entity.Insproduct;
import com.entity.Insrecord;

@Service
public class InsrecordServiceImp implements InsrecordService {

	@Resource
	private InsrecordMapper im;
	@Resource
	private InsproductMapper ipm;
	@Resource
	private InsfollowMapper ifm;

	@Override
	public boolean addInsrecord(Freeinsrecord freeinsrecord, int uid) {
		int i = im.addInsrecord(freeinsrecord, uid);
		if(i>0){
			return true;
		}
		return false;
	}

	@Override
	public List<Insrecord> findByPage(Integer page, Integer rows) {
		Integer start = (page - 1) * rows;
		List<Insrecord> list = im.findByPage(start, rows);
		if (list == null) {
			list = new ArrayList<Insrecord>();
		}
		return list;
	}

	@Override
	public Long findCount() {
		Long count = 0L;
		count = im.findCount();
		System.out.println(count);
		if (count == null) {
			count = 0L;
		}
		return count;
	}

	@Override
	public boolean updateIns(Insrecord ins) {
		int i = im.updateIns(ins);
		if(i>0){
			return true;
		}
		return false;
	}

	@Override
	public List<Insproduct> findInsProduct() {
		List<Insproduct> list = ipm.findInsProduct();
		if(list==null){
			list = new ArrayList<Insproduct>();
		}
		return list;
	}

	@Override
	public List<Insfollow> findInsfollow(int id) {
		List<Insfollow> list = ifm.findInsfollow(id);
		if(list==null){
			list = new ArrayList<Insfollow>();
		}
		return list;
	}

	@Override
	public boolean addfollow(Insfollow insfollow,int id) {
		int i = ifm.addfollow(insfollow,id);
		if(i>0){
			return true;
		}
		return false;
	}

	@Override
	public boolean updateIns2(int id) {
		int i = im.updateIns2(id);
		if(i>0){
			return true;
		}
		return false;
	}

	@Override
	public List<Insrecord> findByInsStatus() {
		List<Insrecord> list = im.findByInsStatus();
		if(list==null){
			list = new ArrayList<Insrecord>();
		}
		return list;
	}

	@Override
	public boolean updateIns3(int id) {
		int i = im.updateIns3(id);
		if(i>0){
			return true;
		}
		return false;
	}

	@Override
	public List<Insrecord> findByInsStatus2() {
		List<Insrecord> list = im.findByInsStatus2();
		if(list==null){
			list = new ArrayList<Insrecord>();
		}
		return list;
	}

	@Override
	public boolean addproduct(int pid,int id) {
		int i = im.addproduct(pid,id);
		if(i>0){
			return true;
		}
		return false;
	}


}
