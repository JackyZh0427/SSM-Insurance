package com.entity;

import java.io.Serializable;

/**
 * 
 * 主要作用
 * 将错误或者正确的状态和消息封装起来
 *
 */
public class ResultMsg implements Serializable{
	private boolean flag=false;
	private String msg;
	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public ResultMsg(boolean flag, String msg) {
		super();
		this.flag = flag;
		this.msg = msg;
	}
	public ResultMsg() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
