package com.entity;

import java.io.Serializable;

public class Sysuser  implements Serializable{
	  private Integer id;
	  private String name;
	  private String pwd;
	  private Integer did;
	  private Integer rid;
	  private Integer level;
	  private Integer isdel;
	  private String remark;
	  
	  public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public Integer getDid() {
		return did;
	}
	public void setDid(Integer did) {
		this.did = did;
	}
	public Integer getRid() {
		return rid;
	}
	public void setRid(Integer rid) {
		this.rid = rid;
	}
	public Integer getLevel() {
		return level;
	}
	public void setLevel(Integer level) {
		this.level = level;
	}
	public Integer getIsdel() {
		return isdel;
	}
	public void setIsdel(Integer isdel) {
		this.isdel = isdel;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Sysuser(Integer id, String name, String pwd, Integer did,
			Integer rid, Integer level, Integer isdel, String remark) {
		super();
		this.id = id;
		this.name = name;
		this.pwd = pwd;
		this.did = did;
		this.rid = rid;
		this.level = level;
		this.isdel = isdel;
		this.remark = remark;
	}
	public Sysuser() {
		super();
		// TODO Auto-generated constructor stub
	}
	  
}
