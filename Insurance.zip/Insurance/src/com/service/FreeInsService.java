package com.service;

import java.util.List;

import com.entity.Freeinsrecord;
import com.entity.Insrecord;

public interface FreeInsService {
	
	public List<Freeinsrecord> findAll();
	
	public List<Freeinsrecord> findByPage(int uid,Integer page,Integer rows);
	
	public List<Freeinsrecord> findByPage2(Integer page,Integer rows);//免险提交分页
	
	public Long findCount();//免险总人数
	
	public Long findCount2();//免险提交人数
	
	public boolean updateFreeIns(Freeinsrecord fir);//更新
	
	public boolean deletefreeIns(int id);
	
	public boolean updateStatus(int id);
	
	public boolean updateStatus2(int id);
	
	public boolean insertfreeIns(Freeinsrecord fir);
	
}
