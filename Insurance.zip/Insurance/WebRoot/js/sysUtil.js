function getDate(milliseconds){
	var bt=new Date(milliseconds);
	var year=bt.getFullYear();
	var month=bt.getMonth();
	var day=bt.getDate();
	var date=year+"-"+month+"-"+day;
	return date;
}
/**
 * 转换字典数据(比如性别,民族,意向,婚否)
 */
function formatData(dataType,status){
	var datas=null;
	switch(dataType){
	case "负责人":
		datas={"data":[
			{"id":"1","text":"Tom"},
			{"id":"2","text":"张保"},
			{"id":"3","text":"张免"},
			{"id":"4","text":"老王"},
			{"id":"5","text":"老宋"}
		]};
		break;
	case "性别":
		datas={"data":[
			{"id":"0","text":"男"},
			{"id":"1","text":"女"}
		]};
		break;
	case "民族":
		datas={"data":[
			{"id":"1","text":"汉族"},
			{"id":"2","text":"少数名族"}
		]};
		break;
	case "满意度":
		datas={"data":[
		    	{"id":"1","text":"A"},
		    	{"id":"2","text":"B"},
		    	{"id":"3","text":"C"},
		    	{"id":"4","text":"D"}
			   ]};
		break;
	case "婚否":
		datas={"data":[
		    	{"id":"1","text":"未婚"},
		    	{"id":"2","text":"已婚"},
		    	{"id":"3","text":"离婚"},
		    	{"id":"4","text":"丧偶"}
			   ]};
		break;
	case "免险状态":
		datas={"data":[
		    	{"id":"1","text":"未提交"},
		    	{"id":"2","text":"已提交"},
		    	{"id":"3","text":"已确认"}
			   ]};
		break;
		
	case "保险状态":
		datas={"data":[
		    	{"id":"1","text":"未提交确认"},
		    	{"id":"2","text":"已提交并确认"},
		    	{"id":"3","text":"已到账"}
			   ]};
	break;
	case "产品信息":
		datas={"data":[
		    	{"id":"1","text":"意外险"},
		    	{"id":"2","text":"车险"},
		    	{"id":"3","text":"教育险"},
		    	{"id":"4","text":"医疗险"}
			   ]};
	break;
	}
	var result="无";
	//遍历对应的数据
	$.each(datas.data,function(i, n){
		if(status==n.id){
			result=n.text;	
		}
	});
	return result;
	
}

	

