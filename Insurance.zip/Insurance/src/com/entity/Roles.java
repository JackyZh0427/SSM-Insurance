package com.entity;

import java.io.Serializable;

public class Roles implements Serializable {
	private Integer id;
	private String rname;
	private Integer level;
	private String remark;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRname() {
		return rname;
	}

	public void setRname(String rname) {
		this.rname = rname;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Roles(Integer id, String rname, Integer level, String remark) {
		super();
		this.id = id;
		this.rname = rname;
		this.level = level;
		this.remark = remark;
	}

	public Roles() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Roles [id=" + id + ", rname=" + rname + ", level=" + level + ", remark=" + remark + "]";
	}
	

}
