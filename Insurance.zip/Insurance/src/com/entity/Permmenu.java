package com.entity;

import java.io.Serializable;

public class Permmenu implements Serializable{
	private Integer rid;
	private String menuname;
	private String remark;
	public Integer getRid() {
		return rid;
	}
	public void setRid(Integer rid) {
		this.rid = rid;
	}
	public String getMenuname() {
		return menuname;
	}
	public void setMenuname(String menuname) {
		this.menuname = menuname;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Permmenu(Integer rid, String menuname, String remark) {
		super();
		this.rid = rid;
		this.menuname = menuname;
		this.remark = remark;
	}
	public Permmenu() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
