package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.entity.Freeinsrecord;

public interface AssignInfoMapper {
	
	public List<Freeinsrecord> findByPage(@Param("start")Integer start,@Param("rows")Integer rows);
	
	public Long findCount();
	
	public int updFreeIns(int id);
	
}
