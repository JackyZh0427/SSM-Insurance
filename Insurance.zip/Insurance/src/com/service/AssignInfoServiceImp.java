package com.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dao.AssignInfoMapper;
import com.dao.FreeInsMapper;
import com.entity.Freeinsrecord;
@Service
public class AssignInfoServiceImp implements AssignInfoService{
	
	@Resource
	private AssignInfoMapper aim;
	@Resource
	private FreeInsMapper fim;
	

	@Override
	public List<Freeinsrecord> findByPage(Integer page, Integer rows) {
		Integer start = (page - 1) * rows;
		List<Freeinsrecord> flist = aim.findByPage(start, rows);
		if (flist == null) {
			flist = new ArrayList<Freeinsrecord>();
		}
		return flist;
	}

	@Override
	public Long findCount() {
		Long count = 0L;
		count = aim.findCount();
		System.out.println(count);
		if (count == null) {
			count = 0L;
		}
		return count;
	}

	@Override
	public List<Freeinsrecord> findByUserId(int id) {
		List<Freeinsrecord> list = fim.findByUserId(id);
		if(list==null){
			 list = new ArrayList<Freeinsrecord>();
		}
		return list;
	}

	@Override
	public boolean updFreeIns(int id) {
		int i = aim.updFreeIns(id);
		if(i>0){
			return true;
		}
		return false;
		
	}

}
