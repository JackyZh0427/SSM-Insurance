package com.entity;

import java.io.Serializable;

public class Insproduct implements Serializable{
    private Integer id;
	private String pname;
	private Integer cycle;
	private Integer price;
	private String remark;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public Integer getCycle() {
		return cycle;
	}
	public void setCycle(Integer cycle) {
		this.cycle = cycle;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Insproduct() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Insproduct(Integer id, String pname, Integer cycle, Integer price,
			String remark) {
		super();
		this.id = id;
		this.pname = pname;
		this.cycle = cycle;
		this.price = price;
		this.remark = remark;
	}
	
}
