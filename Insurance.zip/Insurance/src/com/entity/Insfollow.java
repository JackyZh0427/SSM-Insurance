package com.entity;

import java.io.Serializable;
import java.util.Date;

public class Insfollow implements Serializable{
    private Integer id;
	private Date visitTime;
	private String visitContent;
	private Integer insId;
	private String remark;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Date getVisitTime() {
		return visitTime;
	}
	public void setVisitTime(Date visitTime) {
		this.visitTime = visitTime;
	}
	public String getVisitContent() {
		return visitContent;
	}
	public void setVisitContent(String visitContent) {
		this.visitContent = visitContent;
	}
	public Integer getInsId() {
		return insId;
	}
	public void setInsId(Integer insId) {
		this.insId = insId;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Insfollow() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Insfollow(Integer id, Date visitTime, String visitContent,
			Integer insId, String remark) {
		super();
		this.id = id;
		this.visitTime = visitTime;
		this.visitContent = visitContent;
		this.insId = insId;
		this.remark = remark;
	}
	
}
