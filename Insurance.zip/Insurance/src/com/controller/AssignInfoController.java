package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.dao.FreeInsMapper;
import com.entity.Freeinsrecord;
import com.entity.Insrecord;
import com.entity.Pagebean;
import com.entity.ResultMsg;
import com.entity.Sysuser;
import com.service.AssignInfoService;
import com.service.InsrecordService;
import com.util.SysMsgManager;

@Controller
@RequestMapping("/assignInfoFree")
public class AssignInfoController {

	@Resource
	private AssignInfoService ais;
	@Resource
	private FreeInsMapper fim;
	@Resource
	private InsrecordService is;
	@ResponseBody
	@RequestMapping("/infoFree.do")
	public void freeIns(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=================保险信息====================");
		int page = Integer.parseInt(request.getParameter("page"));
		int rows = Integer.parseInt(request.getParameter("rows"));
		List<Freeinsrecord> flist = ais.findByPage(page, rows);
		Long total = ais.findCount();// 总数
		Pagebean pb = new Pagebean();
		pb.setTotal(total);
		pb.setRows(flist);
		out.println(JSONObject.toJSONString(pb));
	}
	@ResponseBody
	@RequestMapping("/updinfoFree.do")
	public void updfreeIns(int uid,int id,HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=================分配免险信息量====================");
		//查到当前该用户的所有信息
		System.out.println(uid+"==="+id);
		boolean updFreeIns = ais.updFreeIns(id);
		if(updFreeIns){
			Freeinsrecord freeinsrecord = fim.findById(id);
			//把对象插进对应的表中
			boolean flag = is.addInsrecord(freeinsrecord, uid);
			ResultMsg rm = new ResultMsg();
			if (flag) {
				rm.setFlag(true);
				rm.setMsg(SysMsgManager.assignfreeSucc);
			} else {
				rm.setFlag(false);
				rm.setMsg(SysMsgManager.assignfreeError);
			}
			out.println(JSONObject.toJSONString(rm));
		}
		
	}

}
