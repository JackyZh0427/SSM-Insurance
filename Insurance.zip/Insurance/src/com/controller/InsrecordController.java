package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jasper.tagplugins.jstl.core.ForEach;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.entity.Insfollow;
import com.entity.Insproduct;
import com.entity.Insrecord;
import com.entity.Pagebean;
import com.entity.ResultMsg;
import com.service.InsrecordService;
import com.util.SysMsgManager;

@Controller
@RequestMapping("/saleInsrecord")
public class InsrecordController {

	@Resource
	private InsrecordService is;
	@ResponseBody
	@RequestMapping("/infoFree.do")
	public void freeIns(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=================保险信息====================");
		int page = Integer.parseInt(request.getParameter("page"));
		int rows = Integer.parseInt(request.getParameter("rows"));
		List<Insrecord> flist = is.findByPage(page, rows);
		Long total = is.findCount();// 总数
		Pagebean pb = new Pagebean();
		pb.setTotal(total);
		pb.setRows(flist);
		out.println(JSONObject.toJSONString(pb));
	}
	@ResponseBody
	@RequestMapping("/updsaleIns.do")
	public void updateInsrecord(Insrecord ins,HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=================修改====================");
		boolean flag = is.updateIns(ins);
		ResultMsg rm = new ResultMsg();
		if (flag) {
			rm.setFlag(true);
			rm.setMsg(SysMsgManager.UpdateInsrecordSucc);
		} else {
			rm.setFlag(false);
			rm.setMsg(SysMsgManager.UpdateInsrecordError);
		}
		out.println(JSONObject.toJSONString(rm));
	
	}
	//查询所有产品
	@ResponseBody
	@RequestMapping("/InsProduct.do")
	public void findInsproduct(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=================查询产品====================");
		List<Insproduct> list = is.findInsProduct();
		for (Insproduct insproduct : list) {
			System.out.println(insproduct);
		}
		out.println(JSONObject.toJSONString(list));
	
	}
	@ResponseBody
	@RequestMapping("/Insfollow.do")
	public void findInsfollow(int id,HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=================查询回访记录====================");
		System.out.println(id);
		List<Insfollow> list = is.findInsfollow(id);
		for (Insfollow insfollow : list) {
			System.out.println(insfollow);
		}
		out.println(JSONObject.toJSONString(list));
	
	}
	@ResponseBody
	@RequestMapping("/addback.do")
	public void addfollow(Insfollow insfollow,int id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=================添加回访====================");
		boolean flag = is.addfollow(insfollow,id);
		ResultMsg rm = new ResultMsg();
		if (flag) {
			rm.setFlag(true);
			rm.setMsg(SysMsgManager.addfollowMsgSucc);
		} else {
			rm.setFlag(false);
			rm.setMsg(SysMsgManager.addfollowMsgError);
		}
		out.println(JSONObject.toJSONString(rm));
	
	}
	//修改状态为2
	@ResponseBody
	@RequestMapping("/updfollow.do")
	public void UpdInsDword(int id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=================提交并确认====================");
		boolean flag = is.updateIns2(id);
		ResultMsg rm = new ResultMsg();
		if (flag) {
			rm.setFlag(true);
			rm.setMsg(SysMsgManager.SubmitINsMsgSucc);
		} else {
			rm.setFlag(false);
			rm.setMsg(SysMsgManager.SubmitINsMsgError);
		}
		out.println(JSONObject.toJSONString(rm));
	
	}
	//查找状态为2的
	@ResponseBody
	@RequestMapping("/findByInsStatusInsDword.do")
	public void findByStatusInsDword(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=================修改状态====================");
		List<Insrecord> list = is.findByInsStatus();
		out.println(JSONObject.toJSONString(list));
	
	}
	//修改状态为3
	@ResponseBody
	@RequestMapping("/updfollow2.do")
	public void UpdInsDword2(int id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=================经理提交并确认====================");
		boolean flag = is.updateIns3(id);
		ResultMsg rm = new ResultMsg();
		if (flag) {
			rm.setFlag(true);
			rm.setMsg(SysMsgManager.SubmitINsMsgSucc);
		} else {
			rm.setFlag(false);
			rm.setMsg(SysMsgManager.SubmitINsMsgError);
		}
		out.println(JSONObject.toJSONString(rm));
	
	}
	//查找状态为3的
	@ResponseBody
	@RequestMapping("/findByStatusInsDword.do")
	public void findByStatusInsDword2(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=================遍历已到账====================");
		List<Insrecord> list = is.findByInsStatus2();
		out.println(JSONObject.toJSONString(list));
	
	}
	//添加保险产品
	@ResponseBody
	@RequestMapping("/addproduct.do")
	public void addproduct(int pid,int id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("=================购买保险====================");
		boolean flag = is.addproduct(pid,id);
		ResultMsg rm = new ResultMsg();
		if (flag) {
			rm.setFlag(true);
			rm.setMsg(SysMsgManager.BuyInsMsgSucc);
		} else {
			rm.setFlag(false);
			rm.setMsg(SysMsgManager.BuyInsMsgError);
		}
		out.println(JSONObject.toJSONString(rm));
	
	}
	
}
