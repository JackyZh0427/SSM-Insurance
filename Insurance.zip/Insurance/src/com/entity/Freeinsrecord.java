package com.entity;

import java.io.Serializable;
import java.util.Date;

public class Freeinsrecord implements Serializable{
	 private Integer id;
	 private String cstmName;
	 private Integer cstmSex;
	 private Integer cstmAge;
	 private String cstmPhone;
	 private Date beginTime;
	 private String addr;
	 private Integer isMarry;
	 private Integer nation;
	 private Integer intention;
	 private Integer userid;
	 private String remark;
	 private Integer status;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCstmName() {
		return cstmName;
	}
	public void setCstmName(String cstmName) {
		this.cstmName = cstmName;
	}
	public Integer getCstmSex() {
		return cstmSex;
	}
	public void setCstmSex(Integer cstmSex) {
		this.cstmSex = cstmSex;
	}
	public Integer getCstmAge() {
		return cstmAge;
	}
	public void setCstmAge(Integer cstmAge) {
		this.cstmAge = cstmAge;
	}
	public String getCstmPhone() {
		return cstmPhone;
	}
	public void setCstmPhone(String cstmPhone) {
		this.cstmPhone = cstmPhone;
	}
	public Date getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public Integer getIsMarry() {
		return isMarry;
	}
	public void setIsMarry(Integer isMarry) {
		this.isMarry = isMarry;
	}
	public Integer getNation() {
		return nation;
	}
	public void setNation(Integer nation) {
		this.nation = nation;
	}
	public Integer getIntention() {
		return intention;
	}
	public void setIntention(Integer intention) {
		this.intention = intention;
	}
	public Integer getUserid() {
		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Freeinsrecord() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Freeinsrecord(Integer id, String cstmName, Integer cstmSex,
			Integer cstmAge, String cstmPhone, Date beginTime, String addr,
			Integer isMarry, Integer nation, Integer intention, Integer userid,
			String remark, Integer status) {
		super();
		this.id = id;
		this.cstmName = cstmName;
		this.cstmSex = cstmSex;
		this.cstmAge = cstmAge;
		this.cstmPhone = cstmPhone;
		this.beginTime = beginTime;
		this.addr = addr;
		this.isMarry = isMarry;
		this.nation = nation;
		this.intention = intention;
		this.userid = userid;
		this.remark = remark;
		this.status = status;
	}
	 
}
