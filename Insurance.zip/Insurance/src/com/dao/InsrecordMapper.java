package com.dao;



import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.entity.Freeinsrecord;
import com.entity.Insproduct;
import com.entity.Insrecord;


public interface InsrecordMapper {
	
	public int addInsrecord(@Param("f") Freeinsrecord freeinsrecord,@Param("uid") int uid);
	
	
	public List<Insrecord> findByPage(@Param("start") Integer start,@Param("rows") Integer rows);
	
	public Long findCount();
	
	public int updateIns(Insrecord ins);
	
	public int updateIns2(int id);//修改状态
	
	public List<Insrecord> findByInsStatus();
	
	public int updateIns3(int id);
	
	public List<Insrecord> findByInsStatus2();
	
	public int addproduct(@Param("pid") int pid,@Param("id") int id);
	
}
